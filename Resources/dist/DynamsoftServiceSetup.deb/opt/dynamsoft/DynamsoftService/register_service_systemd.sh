#!/bin/sh
cd /opt/dynamsoft/DynamsoftService

systemctl daemon-reload
systemctl stop dynamsoft.service
systemctl disable dynamsoft.service
systemctl daemon-reload
if [ -f "/usr/lib/systemd/system/dynamsoft.service" ]
then
	systemctl enable /usr/lib/systemd/system/dynamsoft.service
elif [ -f "/lib/systemd/system/dynamsoft.service" ]
then
	systemctl enable /lib/systemd/system/dynamsoft.service
else
	systemctl enable /opt/dynamsoft/DynamsoftService/dynamsoft.service
fi
systemctl start dynamsoft.service

#/opt/dynamsoft/DynamsoftService/AutoStartMgr "/opt/dynamsoft/DynamsoftService/DynamsoftServiceMgr&"


